
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'lalami',
  applicationName: 'feedback',
  appUid: '9HzhV1R1lNZz9hnGbn',
  orgUid: 'c1cf5ee2-8845-4fad-9852-31b1d0c1fc58',
  deploymentUid: '726e11ec-26c8-48c6-a101-92457b3b48b4',
  serviceName: 'feedback',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '4.4.2',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'feedback-dev-hello', timeout: 6 };

try {
  const userHandler = require('./handler.js');
  module.exports.handler = serverlessSDK.handler(userHandler.hello, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}